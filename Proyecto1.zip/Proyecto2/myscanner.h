#define IDENTIFIER 1
#define INTEGER 2
#define COMMA 3
#define LPAREN 4
#define RPAREN 5
#define LCURLYBRACE 6
#define RCURLYBRACE 7
#define IF 8
#define ELSE 9
#define CASE 10
#define SWITCH 11
#define COLON 12



//typedef enum tokens {IDENTIFIER, INTEGER} token;

