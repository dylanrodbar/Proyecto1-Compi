#include <stdio.h>
#include <stdbool.h>
#include "myscanner.h"

extern int yylex();
extern int yylineno;
extern char* yytext;

char *names[] = {NULL, "db_type", "db_name", "db_table_prefix", "db_port"};
FILE *file;



void leerArchivo(void){
    printf("Ruta del archivo: \n");
    char NombreArchivo[150];
    gets(NombreArchivo);
    file = fopen(NombreArchivo, "r");
}



/*Función que indica si se leyó o no correctamente el archivo*/
bool seLeyoArchivo(void){
    if (file) {
        return true;

    }else{
    return false;
    }

}

/*Función que se encarga de cerrar el archivo*/
void cerrarArchivo(void){
    fclose(file);
}


int nextToken(void)
{
    return yylex();
}

void preprocess(void)
{
    
}

void scanner(void)
{
    int ntoken, vtoken;
    
    ntoken = nextToken();
    while(ntoken) {
        printf("%d\n", ntoken);

        ntoken = nextToken();
    }
    
    return 0;

}

int main(void)
{
    scanner();
    
}


